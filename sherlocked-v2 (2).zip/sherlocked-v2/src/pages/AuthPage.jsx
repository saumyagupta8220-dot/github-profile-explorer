import { useState } from 'react'
import { API, COLORS } from '../constants'
import {
  Scanline,
  PixelBorder,
  GlitchText,
  ArcadeInput,
  ArcadeButton,
  Toast,
} from '../components/ui'

export default function AuthPage({ setToken }) {
  const [mode, setMode]       = useState('login')
  const [name, setName]       = useState('')
  const [email, setEmail]     = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const [toast, setToast]     = useState(null)

  const handleSubmit = async () => {
    setLoading(true)
    try {
      const url  = mode === 'login' ? `${API}/auth/login` : `${API}/auth/register`
      const body = mode === 'login' ? { email, password } : { name, email, password }

      const res  = await fetch(url, {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify(body),
      })
      const data = await res.json()
      if (!data.success) throw new Error(data.message || data.error)

      if (mode === 'register') {
        setToast({ msg: 'Registered! Now login.', type: 'success' })
        setMode('login')
        setName('')
        setEmail('')
        setPassword('')
      } else {
        setToken(data.token, { email })
      }
    } catch (e) {
      setToast({ msg: e.message, type: 'error' })
    } finally {
      setLoading(false)
    }
  }

  const handleKeyDown = (e) => {
    if (e.key === 'Enter') handleSubmit()
  }

  return (
    <div
      onKeyDown={handleKeyDown}
      style={{
        minHeight: '100vh',
        background: COLORS.bg,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: 24,
        position: 'relative',
      }}
    >
      <link
        href="https://fonts.googleapis.com/css2?family=Press+Start+2P&display=swap"
        rel="stylesheet"
      />
      <Scanline />

      <div style={{ width: '100%', maxWidth: 440, textAlign: 'center', position: 'relative', zIndex: 1 }}>
        {/* Logo */}
        <div style={{ marginBottom: 40 }}>
          <div style={{ fontSize: 48, marginBottom: 8 }}>🔍</div>
          <GlitchText text="SHERLOCKED" size={22} />
          <p
            style={{
              fontFamily: "'Press Start 2P', monospace",
              fontSize: 7,
              color: COLORS.muted,
              marginTop: 12,
              letterSpacing: 2,
            }}
          >
            DETECTIVE CHALLENGE v1.0
          </p>
        </div>

        <PixelBorder style={{ padding: 32, background: COLORS.panel }}>
          {/* Mode tabs */}
          <div
            style={{
              display: 'flex',
              marginBottom: 28,
              border: `1px solid ${COLORS.border}`,
            }}
          >
            {['login', 'register'].map((m) => (
              <button
                key={m}
                onClick={() => setMode(m)}
                style={{
                  flex: 1,
                  padding: '10px 0',
                  background: mode === m ? COLORS.accent : 'transparent',
                  color: mode === m ? '#000' : COLORS.muted,
                  border: 'none',
                  cursor: 'pointer',
                  fontFamily: "'Press Start 2P', monospace",
                  fontSize: 8,
                  letterSpacing: 1,
                  transition: 'all 0.12s',
                }}
              >
                {m.toUpperCase()}
              </button>
            ))}
          </div>

          {mode === 'register' && (
            <ArcadeInput
              label="DETECTIVE NAME"
              value={name}
              onChange={setName}
              placeholder="Enter your alias"
            />
          )}
          <ArcadeInput
            label="EMAIL"
            type="email"
            value={email}
            onChange={setEmail}
            placeholder="detective@agency.com"
          />
          <ArcadeInput
            label="PASSWORD"
            type="password"
            value={password}
            onChange={setPassword}
            placeholder="••••••••"
          />

          <div style={{ marginTop: 8 }}>
            <ArcadeButton fullWidth loading={loading} onClick={handleSubmit}>
              {mode === 'login' ? 'ENTER CASE ROOM' : 'JOIN THE CASE'}
            </ArcadeButton>
          </div>
        </PixelBorder>

        <p
          style={{
            fontFamily: "'Press Start 2P', monospace",
            fontSize: 7,
            color: COLORS.muted,
            marginTop: 24,
            lineHeight: 1.8,
          }}
        >
          INSERT CREDENTIALS TO CONTINUE
        </p>
      </div>

      {toast && (
        <Toast
          message={toast.msg}
          type={toast.type}
          onDone={() => setToast(null)}
        />
      )}
    </div>
  )
}
