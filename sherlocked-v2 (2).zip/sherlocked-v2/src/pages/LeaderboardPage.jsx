import { useState, useEffect } from 'react'
import { COLORS } from '../constants'
import { PixelBorder, GlitchText } from '../components/ui'

const MEDALS = ['🥇', '🥈', '🥉']

const DEFAULT_SCORES = [
  { rank: 1, name: '???', score: '?/3', time: '??:??', status: 'locked' },
  { rank: 2, name: '???', score: '?/3', time: '??:??', status: 'locked' },
  { rank: 3, name: '???', score: '?/3', time: '??:??', status: 'locked' },
]

export default function LeaderboardPage() {
  const [scores]      = useState(DEFAULT_SCORES)
  const [blink, setBlink] = useState(true)

  useEffect(() => {
    const t = setInterval(() => setBlink((b) => !b), 600)
    return () => clearInterval(t)
  }, [])

  return (
    <div style={{ maxWidth: 800, margin: '0 auto', padding: 24 }}>

      {/* Header */}
      <div style={{ textAlign: 'center', marginBottom: 40 }}>
        <div style={{ fontSize: 40, marginBottom: 12 }}>🏆</div>
        <GlitchText text="LEADERBOARD" size={18} />
        <p
          style={{
            fontFamily: "'Press Start 2P', monospace",
            fontSize: 7,
            color: COLORS.muted,
            marginTop: 10,
            letterSpacing: 2,
          }}
        >
          TOP DETECTIVES
        </p>
      </div>

      {/* Scores table */}
      <PixelBorder style={{ background: COLORS.panel, overflow: 'hidden' }}>

        {/* Table header */}
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: '60px 1fr 100px 140px',
            background: '#0a0a12',
            borderBottom: `2px solid ${COLORS.accent}`,
            padding: '12px 20px',
            fontFamily: "'Press Start 2P', monospace",
            fontSize: 8,
            color: COLORS.accentDim,
            letterSpacing: 1,
          }}
        >
          <span>RANK</span>
          <span>DETECTIVE</span>
          <span>SCORE</span>
          <span>LAST SOLVE</span>
        </div>

        {/* Rows */}
        {scores.map((s, i) => (
          <div
            key={s.rank}
            style={{
              display: 'grid',
              gridTemplateColumns: '60px 1fr 100px 140px',
              padding: '18px 20px',
              borderBottom: i < scores.length - 1 ? `1px solid ${COLORS.border}` : 'none',
              background: i === 0 ? '#1a1200' : 'transparent',
              transition: 'background 0.2s',
            }}
          >
            <span style={{ fontFamily: "'Press Start 2P', monospace", fontSize: 14 }}>
              {MEDALS[i] ?? s.rank}
            </span>

            <span
              style={{
                fontFamily: "'Press Start 2P', monospace",
                fontSize: 9,
                color: i === 0 ? COLORS.accent : COLORS.text,
              }}
            >
              {s.status === 'locked'
                ? <span style={{ color: COLORS.muted }}>{'????.?????'}</span>
                : s.name}
            </span>

            <span
              style={{
                fontFamily: "'Press Start 2P', monospace",
                fontSize: 10,
                color: s.score === '3/3' ? COLORS.green : COLORS.text,
              }}
            >
              {s.score}
            </span>

            <span style={{ fontFamily: 'monospace', fontSize: 11, color: COLORS.textDim }}>
              {s.time}
            </span>
          </div>
        ))}
      </PixelBorder>

      {/* Blinking notice */}
      <div style={{ textAlign: 'center', marginTop: 32 }}>
        <p
          style={{
            fontFamily: "'Press Start 2P', monospace",
            fontSize: 8,
            color: blink ? COLORS.cyan : 'transparent',
            letterSpacing: 2,
            transition: 'color 0.1s',
          }}
        >
          RESULTS RELEASED AFTER EVENT ENDS
        </p>
      </div>

      {/* Scoring rules */}
      <div
        style={{
          marginTop: 24,
          background: '#050510',
          border: `1px solid ${COLORS.border}`,
          padding: 20,
          fontFamily: "'Press Start 2P', monospace",
          fontSize: 8,
          color: COLORS.muted,
          lineHeight: 2,
        }}
      >
        <p style={{ color: COLORS.accentDim, marginBottom: 10 }}>SCORING RULES:</p>
        <p>{'>'} 1 POINT PER CORRECT ANSWER</p>
        <p>{'>'} MAX SCORE: 3 / 3</p>
        <p>{'>'} TIE BREAK: EARLIEST LAST CORRECT ANSWER</p>
      </div>

    </div>
  )
}
