import { useState } from 'react'
import { COLORS } from './constants'
import useToken from './hooks/useToken'
import { Scanline } from './components/ui'
import Navbar from './components/Navbar'
import AuthPage from './pages/AuthPage'
import CluesPage from './pages/CluesPage'
import LeaderboardPage from './pages/LeaderboardPage'

export default function App() {
  const { token, user, setToken, logout } = useToken()
  const [page, setPage] = useState('clues')

  if (!token) {
    return <AuthPage setToken={setToken} />
  }

  return (
    <div style={{ minHeight: '100vh', background: COLORS.bg, color: COLORS.text, position: 'relative' }}>
      <link
        href="https://fonts.googleapis.com/css2?family=Press+Start+2P&display=swap"
        rel="stylesheet"
      />

      {/* Animated canvas background — z-index: 0 */}
      <Scanline />

      {/* All UI content above canvas — z-index: 1 */}
      <div style={{ position: 'relative', zIndex: 1 }}>
        <Navbar page={page} setPage={setPage} user={user} logout={logout} />
        <main style={{ padding: '24px 16px' }}>
          {page === 'clues'       && <CluesPage token={token} />}
          {page === 'leaderboard' && <LeaderboardPage />}
        </main>
      </div>
    </div>
  )
}
